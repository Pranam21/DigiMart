package com.digimart.entities;

public enum Role {
	ADMIN, USER

}
