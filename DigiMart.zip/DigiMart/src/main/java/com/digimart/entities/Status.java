package com.digimart.entities;

public enum Status {
Completed, Pending, Failed
}
